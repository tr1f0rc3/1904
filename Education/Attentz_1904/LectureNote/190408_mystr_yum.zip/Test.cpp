﻿#include "pch.h"
#include <iostream>

#include <cassert>

#define SAFE_DELETE(x)		{ if((x)!= nullptr) { delete (x); (x) = nullptr; } }
#define SAFE_DELETE_ARR(x)	{ if((x)!= nullptr) { delete[] (x); (x) = nullptr; } }

#define EXPECT_EQ(x,y)		{ assert((x)==(y) && "not same"); }

unsigned int MyStrlen(const char* pS);
bool MyStrSame(const char* pS1, const char* pS2);
bool MyStrcpy(char* const pBuffer, unsigned int nBufferSize, const char * pSource);



int main(int n, char* s[])
{
	using namespace std;
	
	enum { eCount = 16, eCount2 = 32 };

	// MyStrlen test -----------------------------------------

	cout << MyStrlen("h") << endl;
	cout << MyStrlen("hi") << endl;
	cout << MyStrlen("hih") << endl;
	cout << MyStrlen("hihi") << endl;
	cout << MyStrlen(nullptr) << endl;
	
	const char * p = nullptr;
	
	cout << MyStrlen(p) << endl;

	p = "Hello World!!";
	cout << MyStrlen(p) << endl;

	
	char buffer[eCount] = { "Hello World" };

	cout << MyStrlen(buffer) << endl;


	// MyStrSame test -----------------------------------------

	EXPECT_EQ(MyStrSame("", ""), true);
	EXPECT_EQ(MyStrSame("a", "a"), true);
	EXPECT_EQ(MyStrSame("a", "b"), false);
	EXPECT_EQ(MyStrSame("aa", "aa"), true);
	EXPECT_EQ(MyStrSame("aaa", "aba"), false);
	EXPECT_EQ(MyStrSame("aaa", "baa"), false);
	EXPECT_EQ(MyStrSame("aaa", "aab"), false);
	EXPECT_EQ(MyStrSame("Hello World!!!!", "Hello World!!!!"), true);

	EXPECT_EQ(MyStrSame(nullptr, ""), false);
	EXPECT_EQ(MyStrSame("", nullptr), false);
	EXPECT_EQ(MyStrSame(nullptr, nullptr), false);

	const char * pp = nullptr;
	EXPECT_EQ(MyStrSame(pp, pp), false);

	pp = "Hello World!!";
	EXPECT_EQ(MyStrSame(pp, pp), true);

	char buffer22[eCount] = { "Hello World!!" };
	cout << MyStrlen(buffer22) << endl;

	EXPECT_EQ(MyStrSame(buffer22, buffer22), true);
	EXPECT_EQ(MyStrSame(pp, buffer22), true);


	// MyStrcpy test -----------------------------------------
	char c3Buffer[eCount2] = { 0, };

	MyStrcpy(c3Buffer, eCount2, "");

	EXPECT_EQ(MyStrSame(c3Buffer, ""), true);

	MyStrcpy(c3Buffer, eCount2, "h");
	EXPECT_EQ(MyStrSame(c3Buffer, "h"), true);

	MyStrcpy(c3Buffer, eCount2, "hi");
	EXPECT_EQ(MyStrSame(c3Buffer, "hi"), true);

	const char * pTest = "eoifjeoifjeoifjeoif";

	int nLen = MyStrlen(pTest);

	while (nLen > 0)
	{
		MyStrcpy(c3Buffer, eCount2, pTest);
		EXPECT_EQ(MyStrSame(c3Buffer, pTest), true);

		++pTest;
		--nLen;
	}
	

	







	getchar();
	return 0;
}

unsigned int MyStrlen(const char* pS)
{
	if (pS == nullptr) { return 0; }

	auto* p = pS;

	while (*p != 0)
	{
		++p;
	}

	return p - pS;
}

bool MyStrSame(const char* pS1, const char* pS2)
{
	if (pS1 == nullptr || pS2 == nullptr) { return false; }

	unsigned int nLen = MyStrlen(pS1);
	if (nLen != MyStrlen(pS2)) { return false; }

	while (nLen > 0)
	{
		--nLen;

		if (*pS1 != *pS2)
		{
			return false;
		}

		++pS1;
		++pS2;
	}

	return true;
}
bool MyStrcpy(char* const pBuffer, unsigned int nBufferSize, const char * pSource)
{
	if (pBuffer == nullptr || nBufferSize == 0 || pSource == nullptr) { return false; }

	unsigned int nLen = MyStrlen(pSource);

	if (nBufferSize < (nLen+1)) { return false; }

	char * p = pBuffer;

	// case 1
	while (*pSource != 0)
	{
		*p = *pSource;

		++p;
		++pSource;
	}

	// case 2
	//memcpy_s(pBuffer, nBufferSize, pSource, nLen);
	
	// 얘는 무조건!
	pBuffer[nLen] = 0;

	return true;
}

